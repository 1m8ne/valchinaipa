import discord
from discord.ext import commands
import os
import asyncio
# Using OpenAI integration for external API responses
# the newest OpenAI model is "gpt-5" which was released August 7, 2025.
# do not change this unless explicitly requested by the user
from openai import OpenAI

# Bot configuration - using environment variables for security
DISCORD_BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

if not DISCORD_BOT_TOKEN:
    raise ValueError("DISCORD_BOT_TOKEN environment variable is required")

if not OPENAI_API_KEY:
    raise ValueError("OPENAI_API_KEY environment variable is required")

# Initialize OpenAI client
openai_client = OpenAI(api_key=OPENAI_API_KEY)

# Initialize bot with required intents
intents = discord.Intents.default()
intents.guilds = True
intents.messages = True
intents.dm_messages = True
intents.message_content = True  # Must be enabled in Discord Developer Portal

bot = commands.Bot(command_prefix='!', intents=intents)

async def get_ai_response(prompt: str) -> str:
    """Get AI response from OpenAI GPT-5 API"""
    try:
        print(f"Calling OpenAI GPT-5 for: {prompt[:50]}...")

        # Use GPT-5 to generate a response (run in thread since OpenAI client is sync)
        def call_openai():
            response = openai_client.chat.completions.create(
                model="gpt-5",  # Using the newest OpenAI model
                messages=[
                    {
                        "role": "system", 
                        "content": "You are a helpful, friendly Discord chatbot. Give concise, accurate answers. Be conversational and engaging."
                    },
                    {"role": "user", "content": prompt}
                ],
                max_tokens=300,
                temperature=0.7
            )
            return response.choices[0].message.content

        ai_response = await asyncio.to_thread(call_openai)

        if ai_response:
            ai_response = ai_response.strip()
            print(f"OpenAI response: {ai_response[:100]}...")
            return ai_response
        else:
            return "I received your message but couldn't generate a response."

    except Exception as e:
        print(f"OpenAI API Error: {e}")
        return f"I'm having trouble connecting to my AI brain right now. Error: {str(e)}"

@bot.event
async def on_ready():
    print(f'{bot.user} has connected to Discord!')
    print(f'Bot is in {len(bot.guilds)} guilds')
    print('AI bot powered by OpenAI GPT-5 is ready!')

@bot.command(name='m')
async def chat_command(ctx, *, message):
    """Chat command using !m prefix - powered by OpenAI GPT-5"""
    print(f"!m command from {ctx.author}: '{message}'")

    # Show typing indicator
    async with ctx.typing():
        try:
            # Get AI response from OpenAI
            ai_response = await get_ai_response(message)

            # Split long messages if needed (Discord has 2000 char limit)
            if ai_response and len(ai_response) > 2000:
                chunks = [ai_response[i:i+2000] for i in range(0, len(ai_response), 2000)]
                for chunk in chunks:
                    if chunk:
                        await ctx.reply(chunk)
            elif ai_response:
                await ctx.reply(ai_response)
            else:
                await ctx.reply("I received your message but couldn't generate a response.")

        except Exception as e:
            print(f"Error in !m command: {e}")
            await ctx.reply("Sorry, I'm having technical difficulties right now!")

@bot.event
async def on_message(message):
    """Handle direct messages and mentions"""
    # Don't respond to bot's own messages
    if message.author == bot.user:
        return

    # Check if it's a DM or if the bot is mentioned
    is_dm = isinstance(message.channel, discord.DMChannel)
    is_mentioned = bot.user in message.mentions

    if is_dm or is_mentioned:
        # Remove bot mentions from the message
        content = message.content
        if bot.user:
            content = content.replace(f'<@{bot.user.id}>', '').replace(f'<@!{bot.user.id}>', '').strip()

        # If content is empty after removing mentions, provide a default prompt
        if not content:
            content = "Hi! How can I help you today?"

        print(f"Processing content: '{content}'")

        # Show typing indicator
        async with message.channel.typing():
            try:
                # Get AI response from OpenAI
                ai_response = await get_ai_response(content)

                # Split long messages if needed
                if ai_response and len(ai_response) > 2000:
                    chunks = [ai_response[i:i+2000] for i in range(0, len(ai_response), 2000)]
                    for chunk in chunks:
                        if chunk:
                            await message.reply(chunk)
                elif ai_response:
                    await message.reply(ai_response)
                else:
                    await message.reply("I received your message but couldn't generate a response.")

            except Exception as e:
                print(f"Error in message handling: {e}")
                await message.reply("Sorry, I'm having technical difficulties right now!")

    # Process commands
    await bot.process_commands(message)

if __name__ == "__main__":
    bot.run(DISCORD_BOT_TOKEN)